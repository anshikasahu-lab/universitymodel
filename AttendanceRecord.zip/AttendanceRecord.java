import java.util.HashMap;

public class AttendanceRecord {
    private Student student;
    private HashMap<String, String> attendanceMap; 
    // date -> Present/Absent

    public AttendanceRecord(Student student) {
        this.student = student;
        attendanceMap = new HashMap<>();
    }

    public void markAttendance(String date, String status) {
        attendanceMap.put(date, status);
    }

    public void showAttendance() {
        System.out.println("Attendance Report for: " + student.getName());
        for (String date : attendanceMap.keySet()) {
            System.out.println(date + " -> " + attendanceMap.get(date));
        }
    }

    public String getStudentId() {
        return student.getId();
    }
}
