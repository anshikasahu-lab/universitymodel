public class Student {
    private String name;
    private String id;
    private String department;

    public Student(String name, String id, String department) {
        this.name = name;
        this.id = id;
        this.department = department;
    }

    public String getName() { return name; }
    public String getId() { return id; }
    public String getDepartment() { return department; }
}
