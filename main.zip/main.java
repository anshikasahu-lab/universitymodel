import java.util.*;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        ArrayList<Student> students = new ArrayList<>();
        ArrayList<AttendanceRecord> records = new ArrayList<>();

        while (true) {
            System.out.println("\n=== UNIVERSITY ATTENDANCE SYSTEM ===");
            System.out.println("1. Add Student");
            System.out.println("2. Mark Attendance");
            System.out.println("3. View Attendance Report");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");
            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {

                case 1:
                    System.out.print("Enter Student Name: ");
                    String name = sc.nextLine();

                    System.out.print("Enter Student ID: ");
                    String id = sc.nextLine();

                    System.out.print("Enter Department: ");
                    String dept = sc.nextLine();

                    Student s = new Student(name, id, dept);
                    students.add(s);
                    records.add(new AttendanceRecord(s));
                    System.out.println("Student Added Successfully!");
                    break;

                case 2:
                    System.out.print("Enter Student ID: ");
                    String sid = sc.nextLine();

                    AttendanceRecord ar = null;
                    for (AttendanceRecord r : records) {
                        if (r.getStudentId().equals(sid)) {
                            ar = r;
                            break;
                        }
                    }

                    if (ar == null) {
                        System.out.println("Student not found!");
                        break;
                    }

                    System.out.print("Enter Date (dd-mm-yyyy): ");
                    String date = sc.nextLine();

                    System.out.print("Enter Status (Present/Absent): ");
                    String status = sc.nextLine();

                    ar.markAttendance(date, status);
                    System.out.println("Attendance Marked!");
                    break;

                case 3:
                    System.out.print("Enter Student ID: ");
                    String studId = sc.nextLine();

                    AttendanceRecord rec = null;
                    for (AttendanceRecord r : records) {
                        if (r.getStudentId().equals(studId)) {
                            rec = r;
                            break;
                        }
                    }

                    if (rec == null) {
                        System.out.println("Student not found!");
                        break;
                    }

                    rec.showAttendance();
                    break;

                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);

                default:
                    System.out.println("Invalid Choice!");
            }
        }
    }
}
